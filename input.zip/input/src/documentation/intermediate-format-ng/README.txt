IMPORTANT! This is "WORK IN PROGRESS"!

This directory contains the draft XML schema for a new intermediate format for Apache FOP.
The design is described on the FOP Wiki at:
http://wiki.apache.org/xmlgraphics-fop/AreaTreeIntermediateXml/NewDesign

Help and feedback is welcome.